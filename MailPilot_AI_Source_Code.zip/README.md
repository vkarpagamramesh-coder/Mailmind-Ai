# MailPilot AI — Trainable Email Intelligence (Beginner Project)

This project gives you a Python backend you can run from VS Code or another IDE.

## What it does
- Trains three text-classification models from labeled examples: spam status, email category, and priority.
- Uses TF-IDF + Logistic Regression (a beginner-friendly baseline).
- Exposes a FastAPI endpoint at `POST /analyze`.
- Produces an extractive summary and simple action-item suggestions.
- Includes a tiny demo dataset so you can test the pipeline immediately.

## Important
The included CSV is only a tiny DEMO dataset to prove the pipeline runs. It is not enough for reliable real-world spam detection. Collect a larger, correctly labeled dataset before trusting predictions. Never automatically delete or send emails based only on this model. Treat model results as suggestions for a human to review.

## 1. Install Python
Use Python 3.10 or 3.11. Check:
```bash
python --version
```

## 2. Open the folder in VS Code
Open this `mailpilot_ml_project` folder in VS Code. Open Terminal > New Terminal.

## 3. Create and activate a virtual environment

Windows PowerShell:
```powershell
python -m venv .venv
.venv\\Scripts\\Activate.ps1
```

If activation is blocked, you can use Command Prompt:
```bat
.venv\\Scripts\\activate.bat
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 4. Install dependencies
```bash
pip install -r requirements.txt
```

## 5. Train the models
```bash
python train.py
```
This reads `data/emails.csv` and writes trained model files to `models/`.

## 6. Start the API
```bash
uvicorn app:app --reload
```
Open http://127.0.0.1:8000/docs to test the API in your browser.

## 7. Test an email
Use the Swagger UI at `/docs`, choose `POST /analyze`, then click "Try it out". Example:
```json
{
  "sender": "unknown@example.net",
  "subject": "You won a free gift, click here now",
  "body": "Dear user, claim your free gift now at http://suspicious.example"
}
```

## 8. How to improve training quality
1. Get a legally usable email dataset with spam/ham labels. Remove personal information.
2. Add columns matching the schema in `data/emails.csv`.
3. Use labels that are reviewed by a person, not guesses from the model.
4. Aim for hundreds or thousands of examples per class; class balance matters.
5. Split train/test data and evaluate precision, recall, F1 and a confusion matrix.
6. For spam, prioritize high precision so legitimate emails are not incorrectly marked as spam.
7. Keep a separate `spam_status` from `priority`: an urgent legitimate email and a suspicious email are different concepts.

## Dataset CSV schema
- `subject`: email subject
- `body`: email text
- `spam_status`: `Not spam` or `Spam`
- `category`: `Work`, `Finance`, `Meeting`, `Personal`, or `Other`
- `priority`: `High`, `Medium`, or `Low`

The demo dataset has very few examples. Add many varied, realistic examples for every label before relying on results.

## Frontend integration
Your existing HTML prototype currently uses browser-side keyword rules. This backend is a separate trainable API. To connect it, change the frontend JavaScript to send the sender, subject and body to `http://127.0.0.1:8000/analyze` with `fetch()`, then render the JSON response. If you later deploy it, configure CORS for your actual frontend origin rather than using a wildcard.


## Promotional email safety-net
The API now includes a separate heuristic review for unsolicited training/course promotions, nomination forms, QR-code calls to action, and limited-seat language. This helps catch the kind of message shown in the example, but does not prove the email is malicious. A legitimate college or employer can send course announcements too. Verify the sender and destination URL, and keep human review enabled.
