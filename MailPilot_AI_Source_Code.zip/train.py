from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "emails.csv"
MODEL_DIR = BASE_DIR / "models"
MODEL_DIR.mkdir(exist_ok=True)

TEXT_COLUMNS = ["subject", "body"]
TARGETS = ["spam_status", "category", "priority"]

def main():
    df = pd.read_csv(DATA_PATH).fillna("")
    required = TEXT_COLUMNS + TARGETS
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"CSV is missing columns: {missing}")

    df["text"] = (
        "Subject: " + df["subject"].astype(str) +
        "\nEmail: " + df["body"].astype(str)
    )
    print(f"Loaded {len(df)} labeled examples.")
    print("NOTE: This demo dataset is intentionally tiny; metrics are not reliable.")

    for target in TARGETS:
        counts = df[target].value_counts()
        print(f"\nTraining {target}; labels: {counts.to_dict()}")
        # A stratified split needs at least two examples in every class.
        can_evaluate = len(df) >= 8 and counts.min() >= 2
        model = Pipeline([
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), lowercase=True,
                                      strip_accents="unicode", sublinear_tf=True)),
            ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
        ])

        if can_evaluate:
            try:
                x_train, x_test, y_train, y_test = train_test_split(
                    df["text"], df[target], test_size=0.25, random_state=42,
                    stratify=df[target]
                )
                model.fit(x_train, y_train)
                predictions = model.predict(x_test)
                print(f"Holdout accuracy: {accuracy_score(y_test, predictions):.3f}")
                print(classification_report(y_test, predictions, zero_division=0))
            except ValueError as exc:
                print(f"Could not create a valid holdout split: {exc}")
        model.fit(df["text"], df[target])
        out_path = MODEL_DIR / f"{target}.joblib"
        joblib.dump(model, out_path)
        print(f"Saved: {out_path}")

    metadata = {
        "model_type": "TF-IDF + LogisticRegression",
        "targets": TARGETS,
        "training_rows": len(df),
        "warning": "Demo dataset only. Validate with a large, separate test set before use."
    }
    (MODEL_DIR / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print("\nTraining complete. Start the API with: uvicorn app:app --reload")

if __name__ == "__main__":
    main()
