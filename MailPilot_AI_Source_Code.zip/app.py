from pathlib import Path
import re
import joblib
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "models"

app = FastAPI(title="MailPilot AI API", version="1.0.0",
              description="Email spam, category and priority classification demo.")

# Development convenience only. In production, replace "*" with your frontend origin.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

class EmailInput(BaseModel):
    sender: str = Field(default="", max_length=300)
    subject: str = Field(min_length=1, max_length=500)
    body: str = Field(min_length=1, max_length=30000)

def load_model(name):
    path = MODEL_DIR / f"{name}.joblib"
    if not path.exists():
        return None
    return joblib.load(path)

@app.get("/")
def root():
    return {"app": "MailPilot AI", "status": "running",
            "docs": "/docs", "hint": "Train models with python train.py first."}

@app.get("/health")
def health():
    missing = [name for name in ("spam_status", "category", "priority")
               if not (MODEL_DIR / f"{name}.joblib").exists()]
    return {"status": "ready" if not missing else "models_missing",
            "missing_models": missing}

def heuristic_spam_review(subject: str, body: str, sender: str = ""):
    """
    Safety-net rules for common unsolicited promotions and phishing signals.
    This is not a replacement for a trained spam classifier or sender authentication.
    """
    text = f"{subject} {body}".lower()
    score = 0
    reasons = []

    def add(condition, points, reason):
        nonlocal score
        if condition:
            score += points
            reasons.append(reason)

    # Unsolicited course / webinar / nomination promotions.
    add(
        any(term in text for term in [
            "ai training course", "training course", "learn generative ai",
            "build real projects", "future-proof your career",
            "nominations", "nomination form", "limited spots",
            "spots are limited", "limited seats", "limited slots",
            "register now", "enroll now", "upcoming course",
            "skills that top employers", "qr code"
        ]),
        2,
        "Promotional training or course language"
    )
    add(
        any(term in text for term in [
            "fill out this short", "nomination form", "register here",
            "click here", "below link", "scan the qr", "limited time"
        ]),
        1,
        "Call to action or form/link request"
    )
    add(
        any(term in text for term in [
            "you have won", "claim your prize", "free gift",
            "verify your password", "send your password",
            "gift card", "wire transfer", "send bitcoin"
        ]),
        3,
        "Common phishing or scam wording"
    )
    add(
        any(term in text for term in [
            "unsubscribe", "promotional offer", "special offer",
            "discount", "marketing newsletter"
        ]),
        1,
        "Marketing or newsletter indicators"
    )
    if score >= 3:
        status = "Likely spam / unsolicited promotion"
        level = "high"
    elif score >= 2:
        status = "Suspicious promotion — review"
        level = "medium"
    elif score == 1:
        status = "Possible promotional email — review"
        level = "low"
    else:
        status = "No obvious spam signals"
        level = "none"

    return {"status": status, "level": level, "score": score, "reasons": reasons}


def make_summary(body: str, max_chars: int = 260) -> str:
    # Simple extractive summary baseline; not an LLM-generated summary.
    sentences = re.split(r"(?<=[.!?])\s+", body.strip())
    result = " ".join(s for s in sentences[:2] if s)
    return result[:max_chars - 1] + "…" if len(result) > max_chars else result

def extract_actions(body: str):
    # Heuristic baseline. Review extracted tasks before acting on them.
    patterns = [
        r"\b(?:please|must|need to|needs to|should|kindly)\s+[^.!?;\n]{5,120}",
        r"\b(?:confirm|submit|send|review|complete|update|share|reply|register|pay|finalize|schedule|provide)\s+[^.!?;\n]{4,100}"
    ]
    actions = []
    for pattern in patterns:
        for match in re.finditer(pattern, body, flags=re.IGNORECASE):
            text = re.sub(r"\s+", " ", match.group(0)).strip()
            if text.lower() not in {a.lower() for a in actions}:
                actions.append(text)
            if len(actions) >= 5:
                return actions
    return actions

@app.post("/analyze")
def analyze_email(email: EmailInput):
    models = {name: load_model(name) for name in ("spam_status", "category", "priority")}
    missing = [name for name, model in models.items() if model is None]
    if missing:
        raise HTTPException(status_code=503,
            detail=f"Models missing: {missing}. Run `python train.py` first.")

    text = f"Subject: {email.subject}\nEmail: {email.body}"
    predictions = {}
    confidence = {}
    for name, model in models.items():
        predictions[name] = str(model.predict([text])[0])
        try:
            probabilities = model.predict_proba([text])[0]
            confidence[name] = round(float(max(probabilities)), 3)
        except (AttributeError, ValueError):
            confidence[name] = None

    spam_review = heuristic_spam_review(email.subject, email.body, email.sender)
    predicted_spam = predictions["spam_status"]
    # Conservative safety net: rule signals can escalate a model result for human review,
    # but should not automatically delete or block an email.
    if spam_review["level"] == "high":
        predicted_spam = "Spam — review required"
    elif spam_review["level"] == "medium" and predicted_spam.lower() in ("not spam", "ham", "legitimate"):
        predicted_spam = "Suspicious — review required"

    return {
        "sender": email.sender,
        "subject": email.subject,
        "spam_status": predicted_spam,
        "spam_rule_review": spam_review,
        "category": predictions["category"],
        "priority": predictions["priority"],
        "confidence": confidence,
        "summary": make_summary(email.body),
        "follow_up_actions": extract_actions(email.body),
        "human_review_required": True,
        "disclaimer": "Demo ML model trained on a tiny sample. Predictions and confidence are not reliable until trained and tested on a larger representative dataset."
    }
